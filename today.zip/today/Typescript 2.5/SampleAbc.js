var myName = "Abhishek";
var myAge = 23;
document.write("Hello World");
