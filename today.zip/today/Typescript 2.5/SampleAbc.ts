var myName:string= "Abhishek";
var myAge:number=23;

document.write("Hello World");